namespace Shepard_Hawj_CPT_206_A01S_Lab_5_Web_API.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
